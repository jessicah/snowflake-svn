external f : 'a -> 'b = "%identity";
