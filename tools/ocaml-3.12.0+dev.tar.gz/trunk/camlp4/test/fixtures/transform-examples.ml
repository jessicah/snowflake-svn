<:expr< $x$ + $y$ - $z$ >> -> <:expr< plus_minus $x$ $y$ $z$ >>

<< List.rev (List.rev $l$) >> -> l
