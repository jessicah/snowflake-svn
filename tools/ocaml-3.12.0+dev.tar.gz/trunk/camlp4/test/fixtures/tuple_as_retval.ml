EXTEND Gram
  abc: [ [ (x,y) = foo -> x+y ] ];
END;
