EXTEND Gram
  raw_string:
  [[ `QUOTATION { Sig.Quotation.q_contents = c; q_name = n } -> (c, n) ]];
END;
