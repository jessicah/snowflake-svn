<:expr< EXTEND G expr: [[ "foo" -> <:expr< foo >> ]]; END >>;
