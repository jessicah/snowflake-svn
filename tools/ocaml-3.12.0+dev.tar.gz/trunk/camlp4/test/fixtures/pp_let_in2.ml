let i = "toto" in ((let i = 42 in print_int i); print_string i)
