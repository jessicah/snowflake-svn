(* Open a persistent pattern
 * $Id: 51_open_pattern.ml 142 2008-07-17 15:45:56Z richard.wm.jones $
 *)

open Printf
open Bitstring

open bitmatch "tests/test.bmpp"

let () =
  let bits = bitstring_of_string "\022Mary had a little lamb" in
  bitmatch bits with
  | { :pascal_string } ->
      () (*printf "it's a Pascal string, len = %d, string = %S\n" len str*)
  | { _ } ->
      eprintf "not matching error\n";
      exit 1
