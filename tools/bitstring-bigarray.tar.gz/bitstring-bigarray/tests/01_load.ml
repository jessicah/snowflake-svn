(* Just check that the extension and library load without error.
 * $Id: 01_load.ml 142 2008-07-17 15:45:56Z richard.wm.jones $
 *)

let _ = Bitstring.extract_bit
