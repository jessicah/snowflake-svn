(* Just check that we can run some functions from the library.
 * $Id: 02_run.ml 142 2008-07-17 15:45:56Z richard.wm.jones $
 *)

let () =
  let bits = Bitstring.create_bitstring 16 in
  ignore (Bitstring.string_of_bitstring bits)
